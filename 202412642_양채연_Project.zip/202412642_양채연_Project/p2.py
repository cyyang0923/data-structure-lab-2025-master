# 사용자로부터 괄호열 입력 받기
input_str = input().strip()

def problem2(input):
    """
    주어진 올바르지 않은 괄호열을 최소한의 괄호 추가로 올바른 괄호열로 복원할 때,
    앞과 뒤에 붙여야 하는 괄호의 총 개수를 계산합니다.

    Parameters:
    input (str): 괄호로만 이루어진 문자열

    Returns:
    int: 추가해야 할 괄호의 최소 개수
    """
    # 이 곳에 코드를 작성하세요.

    open_needed = 0  # 여는 괄호가 부족한 경우 카운트
    open_count = 0   # 현재 열린 괄호 '('의 수

    for char in input:
        if char == '(':
            open_count += 1  # 열린 괄호 하나 증가
        else:  # 닫는 괄호 ')'
            if open_count > 0:
                open_count -= 1  # 기존 열린 괄호와 짝지음
            else:
                open_needed += 1  # 짝이 될 여는 괄호가 없어서 앞에 '(' 추가 필요

    # 남은 open_count는 닫히지 않은 '(' → 뒤에 ')' 추가 필요
    result = open_needed + open_count
    return result

result = problem2(input_str)

# 예시 입력이 ")())(" 이었다면 정답은 3
print("정답입니다.")
print(result)  # 실제 필요한 괄호 개수 출력
