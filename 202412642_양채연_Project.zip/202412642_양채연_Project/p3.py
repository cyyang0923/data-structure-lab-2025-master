from collections import deque

# 사용자로부터 입력 받기
N = int(input())  # 숲의 크기 N (NxN)
input = [list(map(int, input().strip())) for _ in range(N)]  # 각 줄의 지형 정보를 숫자 리스트로 변환

forest = []  # 숲의 상태를 저장할 리스트

def problem3(input):
    bear_size = 2             # 곰의 초기 크기
    honeycomb_count = 0       # 꿀벌집을 먹은 횟수
    time = 0                  # 곰이 이동한 총 시간
    bear_x, bear_y = 0, 0     # 곰의 초기 위치

    # forest 초기화 (깊은 복사)
    forest = [row[:] for row in input]

    # 곰의 초기 위치(숫자 9) 찾기
    for i in range(N):
        for j in range(N):
            if forest[i][j] == 9:
                bear_x, bear_y = i, j  # 곰의 위치 저장
                forest[i][j] = 0       # 곰이 있던 자리는 빈 칸으로 설정

    print("곰의 초기 위치 x : {0}, y : {1}".format(bear_x, bear_y))

    # 여기에서부터 코드를 작성하세요.

    # 상, 좌, 우, 하 순서로 탐색 (우선순위 유지)
    dx = [-1, 0, 0, 1]
    dy = [0, -1, 1, 0]

    def bfs(x, y, size):
        """
        곰이 현재 위치에서 갈 수 있는 모든 칸을 BFS로 탐색하여,
        먹을 수 있는 벌집 중 가장 가까운 것을 반환
        """
        visited = [[-1]*N for _ in range(N)]
        q = deque()
        q.append((x, y))
        visited[x][y] = 0

        edible = []  # 먹을 수 있는 벌집들: (거리, x, y)

        while q:
            cx, cy = q.popleft()
            for d in range(4):
                nx = cx + dx[d]
                ny = cy + dy[d]
                # 범위 확인 및 미방문 && 이동 가능 여부
                if 0 <= nx < N and 0 <= ny < N and visited[nx][ny] == -1:
                    if forest[nx][ny] <= size:
                        visited[nx][ny] = visited[cx][cy] + 1
                        q.append((nx, ny))
                        # 먹을 수 있는 벌집이면 목록에 추가
                        if 0 < forest[nx][ny] < size:
                            edible.append((visited[nx][ny], nx, ny))

        # 거리, 위쪽, 왼쪽 우선 정렬
        edible.sort()
        return edible[0] if edible else None

    # 반복적으로 벌집을 먹으러 이동
    while True:
        target = bfs(bear_x, bear_y, bear_size)
        if target is None:
            break  # 더 이상 먹을 수 있는 벌집 없음 → 종료

        dist, tx, ty = target
        time += dist                  # 이동 시간 누적
        honeycomb_count += 1         # 벌집 먹은 수 증가
        forest[tx][ty] = 0           # 벌집 먹고 빈 칸으로 처리
        bear_x, bear_y = tx, ty      # 곰의 위치 갱신

        # 곰이 자신의 크기만큼 벌집을 먹으면 크기 증가
        if honeycomb_count == bear_size:
            bear_size += 1
            honeycomb_count = 0

    result = time  # 최종 시간 반환
    return result

# 문제 실행 및 출력
result = problem3(input)
print("정답입니다.")
print(result)
