input = [int(input()) for _ in range(5)]  # 표준 입력으로 5개의 자연수 입력받기

def problem1(input):
    """
    주어진 5개의 자연수 리스트에서 평균과 중앙값을 계산합니다.

    Parameters:
    input (list): 5개의 자연수로 이루어진 리스트

    Returns:
    list: [평균, 중앙값]
    """
    # 이곳에 코드를 작성하세요.
    # 평균은 전체 합을 수의 개수로 나눈 값
    mean = sum(input) // len(input)

    # 중앙값은 정렬한 뒤 가운데 값 (5개의 수 중 3번째 값 → 인덱스 2)
    sorted_input = sorted(input)
    median = sorted_input[2]

    result = [0, 0]
    result[0] = mean
    result[1] = median
    return result

result = problem1(input)

# 정답 검증용
assert result == [34, 30]
print("정답입니다.")

# 평균과 중앙값 출력
print(result[0])  # 평균
print(result[1])  # 중앙값
